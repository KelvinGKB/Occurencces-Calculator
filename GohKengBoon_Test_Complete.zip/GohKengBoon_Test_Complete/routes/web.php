<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get("/","HomeController@index"); //use after submit

/*Route::get('/', function () {
    return view('Result');
});*/

Route::get('/Algorithm_Calculator', function () {
    return view('Algorithm_Calculator');
});

Route::get('Algorithm_Calculator', 'HomeController@Validation');
Route::post('Algorithm_Calculator', 'HomeController@Algorithm_Calculator_Post');


Route::get('Result', function () {
    return view('Result');
});

Route::post("/Algorithm_Calculator","CalculatorController@index"); //use after submit

Route::post("Result","CalculatorController@index"); //use after submit
Route::get("Result","CalculatorController@index"); //use after submit


