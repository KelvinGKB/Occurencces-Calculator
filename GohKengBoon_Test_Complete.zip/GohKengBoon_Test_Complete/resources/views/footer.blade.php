
<style>
 .footer{
   text-align: center;
   background-color: white;
   padding: 15px;
  
 }
</style>


<footer class="footer">
  <div class="container-fluid clearfix">
    <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © 2020 Algorithm Calculator .All rights reserved.</span>
    <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Created By Goh Keng Boon<i class="mdi mdi-heart text-danger"></i>
    </span>
  </div>
</footer>
