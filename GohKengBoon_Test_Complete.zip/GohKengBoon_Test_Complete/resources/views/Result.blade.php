<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Occurences Calculator</title>
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <!-- Styles -->
    <style>
        html, body {
            background-color: #f8f8f8;
            color: #636b6f;
            font-family: 'Nunito', sans-serif;
            font-weight: 200;
            height: 95vh;
            margin: 0;
        }

        .full-height {
            height: 95vh;
        }

        .flex-center {
            display: flex;
            justify-content: center;
        }

        .position-ref {
            position: relative;
        }

        .top-right {
            position: absolute;
            right: 10px;
            top: 18px;
        }

        .content {
            text-align: center;
        }

        .title {
            font-size: 40px;
            margin-top: 30px;
        }


        .m-b-md {
            margin-bottom: 30px;

        }

        .Calculator {
            background-color: white;
            border: 1px solid transparent;
            border-radius: 1.5rem;
            border-style: solid;
            border-color: grey;
        }


        label {
            font-size: 16px
        }

        hr {
            display: block;
            height: 1px;
            border: 0;
            border-top: 1px solid #ccc;
            margin: 1em 0;
            padding: 0;
            margin-bottom: 30px;

        }

        .button {
            float: right;
            margin-top: 20px;
        }

        .btn {
            margin-right: 10px;
        }

        table {
            font-size: 25px;

            text-align: left;
        }

        td {
            height: 100px;
        }


    </style>
</head>
<body>
<div class="flex-center position-ref full-height">

    <div class="content">
        <div class="title m-b-md">
            Welcome, This is Occurrences Calculator.
        </div>

        <div class="container Calculator col-sm-12">
            <div class="panel-body">
                <h2>Result</h2>
                <hr>
                <table>
                    <tr>
                        <td>Number You Entered :</td>
                        <td><?=$num?></td>
                    </tr>
                    <tr>
                        <td>Result :</td>
                        <td>
                            <?php foreach ($result as $k => $v) {
                                echo "[$k] : $v Occurrences<br/>";
                            }?>
                        </td>
                    </tr>
                </table>
                <br>
                <hr>
                <input type="button" name="clear" class="button btn btn-danger btn-lg" value="Clear "
                       onclick="location='/Algorithm_Calculator'">

            </div>


        </div>
    </div>


</div>

@include('footer')
@include('footer-scripts')


</body>
</html>
