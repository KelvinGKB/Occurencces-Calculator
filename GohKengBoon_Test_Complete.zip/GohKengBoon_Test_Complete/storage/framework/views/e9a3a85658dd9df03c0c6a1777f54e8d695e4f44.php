 <script>
                    $(function () {
                        function footerPosition() {
                            $("footer").removeClass("fixed-bottom");
                            var contentHeight = document.body.scrollHeight,
                                winHeight = window.innerHeight;
                            if (!(contentHeight > winHeight)) {
                              
                                $("footer").addClass("fixed-bottom");
                            }
                        }
                        footerPosition();
                        $(window).resize(footerPosition);
                    });
                </script>
<?php /**PATH /Users/kengboongoh/Sites/GohKengBoon_Test_copy/resources/views/footer-scripts.blade.php ENDPATH**/ ?>