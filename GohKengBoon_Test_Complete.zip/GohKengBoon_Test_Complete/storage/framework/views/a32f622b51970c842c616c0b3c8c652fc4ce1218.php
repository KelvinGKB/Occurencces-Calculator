<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Occurences Calculator</title>
        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <!-- Styles -->
        <style>
            html, body {
                background-color: #f8f8f8;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 40px;
                margin-top: 30px;
            }


            .m-b-md {
                margin-bottom: 30px;

             }

             .Calculator{
               background-color: white;
               border: 1px solid transparent;
               border-radius: 1.5rem;
               border-style: solid;
               border-color: grey;
             }



             label{
               font-size: 16px
             }

             hr {
                 display: block;
                 height: 1px;
                 border: 0;
                 border-top: 1px solid #ccc;
                 margin: 1em 0;
                 padding: 0;
                 margin-bottom: 30px;

                 }

              .button{
                float: right;
                margin-top: 20px;
              }

              .btn{
                margin-right: -30px;
              }







        </style>
    </head>
    <body>
        <div class="flex-center position-ref full-height">

            <div class="content">
                <div class="title m-b-md">
                    Welcome, This is Occurrences Calculator.
                </div>

                <div class="container Calculator col-sm-12">
                  <div class="panel-body">
  <h2>Numeric Occurrences Calculator</h2>
  <hr>
     <?php if(count($errors)): ?>
	     <div class="alert alert-danger alert-dismissible">
         <button name="warning" type="button" class="close" data-dismiss="alert">&times;</button>
		         <strong>Error !</strong>  Please Correct your Error stated as Below :
		         <br/>
             <br>
		      <ul>
		       	 <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			       <li><?php echo e($error); ?></li>
			       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		     </ul>
	     </div>
     <?php endif; ?>

     <?php
     if(isset($_POST['submit']))
     {

       $num=$_POST['num'];

       echo $num;
       //$numstring = explode(',', $num);
       //$result = array_count_values($numstring);

       ;
     }

      ?>


  <form class="form-horizontal" method="post" action="/Algorithm_Calculator">
    <div class="form-group <?php echo e($errors->has('num') ? 'has-error' : ''); ?> ">
      <label class="control-label col-sm-3" for="num">Enter The Number:</label>
      <div class="col-sm-9 ">
        <input type="text" class="form-control input-lg" id="num" placeholder="Enter Number eg. 09,11,20,20..." name="num">
         <span class="text-danger"><?php echo e($errors->first('num')); ?></span>
      </div>
    </div>
    <div class="form-group">
      <div class="col-sm-offset-2 col-sm-3 button">
        <button type="submit" class="btn btn-success btn-lg">Calculate</button>
      </div>
    </div>
  </form>
</div>
</div>
            </div>


        </div>

      <?php echo $__env->make('footer-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </body>
</html>
<?php /**PATH /Users/kengboongoh/Sites/GohKengBoon_Test_copy/resources/views/Algorithm_Calculator.blade.php ENDPATH**/ ?>