<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
class CustomValidation extends Controller
{
	public function customVali()
	{
		return view('Algorithm_Calculator');
	}
	public function customValiPost(Request $request)
	{
		$this->validate($request, [
	        'num' => 'required|is_odd_string',
	    ]);
		print_r('done');
	}
}
