<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Calculator extends Controller
{
    function index(Request $request)
    {

      $this->validate($request,[
          'num' => 'required'
        ],[
          'num.required' => 'Number Field cannot be Blank.',
        ]);

      print_r($request->input());

      $numstring = explode(',', trim($num,','));
      $result = array_count_values($numstring);


    }
}
