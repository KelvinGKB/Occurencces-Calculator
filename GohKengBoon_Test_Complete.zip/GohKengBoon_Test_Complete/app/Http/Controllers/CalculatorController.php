<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CalculatorController extends Controller
{
    public function Validation()
    {
        return view('Algorithm_Calculator');
    }

    function index(Request $request)
    {

        $this->validate($request, [
            'num' => 'required'
        ], [
            'num.required' => 'Number Field cannot be Blank.',
        ]);

        //print_r($request->input());
        $num = $request->post('num');
        $numstring = explode(',', trim($num, ','));
        $result = array_count_values($numstring);
        //var_dump($result);
        return view('Result',['num'=>$num,'result'=>$result]);
    }
}
