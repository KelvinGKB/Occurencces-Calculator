<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function Validation()
    {
        return view('Algorithm_Calculator');
    }

    public function index()
    {
        return view('Algorithm_Calculator');
    }

    public function Algorithm_Calculator_Post(Request $request)
    {
        $this->validate($request, [
            'num' => 'required'
        ], [
            'num.required' => 'Number Field cannot be Blank.',
        ]);

    }

}
